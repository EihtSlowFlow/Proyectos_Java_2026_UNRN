package argel.framework;

import java.util.List;
import java.util.Scanner;

/**
 * Componente responsable de mostrar un menú interactivo por consola y ejecutar
 * las acciones seleccionadas.
 */
public class MenuFramework {
    private List<Accion> accionesDisponibles;

    /**
     * Crea un menú con la lista de acciones ya instanciadas.
     * @param accionesDisponibles acciones que se mostrarán en el menú
     */
    public MenuFramework(List<Accion> accionesDisponibles) {
        // Acá ya recibe las acciones construidas, es decir, se crean en otro lugar y se la pasan al menu para que las utilice.
        this.accionesDisponibles = accionesDisponibles;
    }

    /**
     * Muestra el menú por consola y espera la selección del usuario. La opción 0
     * termina la ejecución.
     */
    public void mostrarYEjecutar() {
        Scanner scanner = new Scanner(System.in);
        int opcion = -1;
        while (opcion != 0) {
            System.out.println("Bienvenido, estas son sus opciones:");
            for (int i = 0; i < accionesDisponibles.size(); i++) {
                // Arma el menu a partir de las acciones disponibles, si se agregan más entradas al Config. entonces no se notará el cambio.
                System.out.println((i + 1) + ". " + accionesDisponibles.get(i).nombreItemMenu() + "(" + accionesDisponibles.get(i).descripcionItemMenu() + ")");
            }
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");

            opcion = scanner.nextInt();

            if (opcion > 0 && opcion <= accionesDisponibles.size()) {
                accionesDisponibles.get(opcion - 1).ejecutar();
            } else {
                System.out.println("Fin...");
            }
            System.out.println("___\n");
        }
    }
}