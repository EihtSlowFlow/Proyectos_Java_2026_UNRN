package composite1;

import java.awt.*;

public class Graphics2DAdapter implements Panel {
    Graphics2D g2d;
    public Graphics2DAdapter(Graphics2D g2d) {
        this.g2d = g2d;
    }

    @Override
    public void pintarCirculo(Coordenada coordenada, int radio) {
        this.g2d.drawOval(coordenada.x() - radio,
                coordenada.y() - radio,
                radio * 2,
                radio * 2);
    }

    @Override
    public void pintarLinea(Coordenada coordenada, int longitud) {
        this.g2d.drawLine(coordenada.x(), coordenada.y(), coordenada.x() + longitud, coordenada.y());
    }

    @Override
    public void pintarTexto(Coordenada coordenada, String texto) {
        this.g2d.drawString(texto, coordenada.x(), coordenada.y());
    }
}
