package composite1;

import javax.swing.*;
import java.awt.*;

public class MainAdapter {
    public static void main(String[] args) {
        JFrame ventana = new JFrame();
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setSize(400, 400);

        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                Graphics2D g2d = (Graphics2D) g;

                Panel miPanel = new Graphics2DAdapter(g2d);

                miPanel.pintarCirculo(new Coordenada(100, 100), 50);
                miPanel.pintarLinea(new Coordenada(50, 200), 250);
                miPanel.pintarTexto(new Coordenada(150, 300), "Prueba de funcionalidad del adapter");
            }
        };

        ventana.add(panel);
        ventana.setVisible(true);
    }
}