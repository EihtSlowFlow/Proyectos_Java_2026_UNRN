package composite1;

public interface Panel {
    void pintarCirculo(Coordenada coordenada, int radio);
    void pintarLinea(Coordenada coordenada, int longitud);
    void pintarTexto(Coordenada coordenada, String texto);
}
