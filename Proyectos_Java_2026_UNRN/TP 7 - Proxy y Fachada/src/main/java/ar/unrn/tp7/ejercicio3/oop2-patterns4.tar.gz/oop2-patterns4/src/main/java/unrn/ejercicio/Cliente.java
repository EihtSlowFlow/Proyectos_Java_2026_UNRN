package unrn.ejercicio;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Cliente {
    private ImageLoader cargaImagenes;
    private String path;

    public Cliente(String path) {
        this.path = path;
        this.cargaImagenes = new ProxyLoader();
    }
    public void prepararImagen() {
        try {
            BufferedImage img = this.cargaImagenes.load(this.path);
            System.out.println("Solicitud de carga procesada para: " + this.path);
        } catch (IOException e) {
            System.err.println("Error físico al intentar precargar la imagen: " + e.getMessage());
        }
    }
    public void mostrarImagen() {
        this.cargaImagenes.display();
    }
}