package unrn.ejercicio;

public class ImageGalery {

    public static void main(String[] args) {
        String rutaFoto = "src/main/resources/image1.jpeg";
        Cliente miGaleria = new Cliente(rutaFoto);
        miGaleria.prepararImagen();
        miGaleria.prepararImagen();
        miGaleria.mostrarImagen();
    }
}