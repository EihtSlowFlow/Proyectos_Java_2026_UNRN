package unrn.ejercicio;

import java.awt.image.BufferedImage;
import java.io.IOException;

public interface ImageLoader  {
    BufferedImage load(String path) throws IOException;
    void display();
}
