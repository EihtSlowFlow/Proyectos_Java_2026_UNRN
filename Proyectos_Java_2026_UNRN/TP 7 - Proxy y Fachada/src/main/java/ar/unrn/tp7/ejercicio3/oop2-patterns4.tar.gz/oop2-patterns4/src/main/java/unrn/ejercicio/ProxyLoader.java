package unrn.ejercicio;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class ProxyLoader  implements ImageLoader {
    private BufferedImage image;
    private ImageFile imageFile;

    @Override
    public BufferedImage load(String path) throws IOException {
        if(imageFile == null){
            imageFile = new ImageFile(path);
            image = imageFile.load(path);
        }
        return image;
    }

    @Override
    public void display() {
        this.imageFile.display();
    }
}
