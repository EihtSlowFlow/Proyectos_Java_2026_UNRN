package compras;

import java.util.List;

public abstract class Cliente {
    private List<Producto> compra;
    private String nombre;
    private TipoCliente tipo;
    private float impuestoCliente;

    public Cliente(String nombre, TipoCliente tipo) {
        this.nombre = nombre;
        this.tipo = tipo;
    }

    public void agregarProducto(Producto producto) {
        this.compra.add(producto);
    }

    public TipoCliente tipo() {
        return tipo;
    }

    public List<Producto> compra() {
        return List.copyOf(compra);
    }

    public abstract float impuestoCliente();
    public abstract float costoEnvioCliente();
}
