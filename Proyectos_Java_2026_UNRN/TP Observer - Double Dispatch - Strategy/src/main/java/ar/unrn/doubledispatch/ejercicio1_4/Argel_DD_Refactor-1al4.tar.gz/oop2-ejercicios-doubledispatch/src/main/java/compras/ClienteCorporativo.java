package compras;

public class ClienteCorporativo extends Cliente{
    private static final float DESCUENTO_CORPORATIVO_ENVIOS = 0.05F;
    private static final float DESCUENTO_CORPORATIVO_IMPUESTOS = 0.10F;
    public ClienteCorporativo(String nombre, TipoCliente tipo) {
        super(nombre, tipo);
    }

    @Override
    public float impuestoCliente() {
        return DESCUENTO_CORPORATIVO_IMPUESTOS;
    }

    @Override
    public float costoEnvioCliente() {
        return DESCUENTO_CORPORATIVO_ENVIOS;
    }
}
