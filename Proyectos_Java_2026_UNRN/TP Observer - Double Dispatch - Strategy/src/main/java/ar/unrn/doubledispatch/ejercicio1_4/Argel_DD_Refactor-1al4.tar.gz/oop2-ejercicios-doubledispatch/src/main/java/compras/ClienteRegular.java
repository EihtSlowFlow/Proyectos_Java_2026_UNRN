package compras;

public class ClienteRegular extends Cliente {
    private static final float DESCUENTO_REGULAR_ENVIOS = 0.10F;
    private static final float DESCUENTO_REGULAR_IMPUESTOS = 0.0F;

    public ClienteRegular(String nombre, TipoCliente tipo) {
        super(nombre, tipo);
    }

    @Override
    public float impuestoCliente() {
        return DESCUENTO_REGULAR_IMPUESTOS;
    }

    @Override
    public float costoEnvioCliente() {
        return DESCUENTO_REGULAR_ENVIOS;
    }
}
