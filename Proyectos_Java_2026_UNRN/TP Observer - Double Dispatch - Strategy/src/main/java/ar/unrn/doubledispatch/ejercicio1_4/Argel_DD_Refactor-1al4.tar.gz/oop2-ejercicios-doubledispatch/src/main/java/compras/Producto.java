package compras;

public interface Producto {

    float precio();

    float costoEnvio(Cliente tipo);

    float impuesto(Cliente tipo);
}
