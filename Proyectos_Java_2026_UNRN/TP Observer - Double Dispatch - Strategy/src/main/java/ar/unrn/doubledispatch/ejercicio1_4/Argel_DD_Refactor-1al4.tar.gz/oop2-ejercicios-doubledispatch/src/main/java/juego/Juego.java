package juego;

import java.util.*;

public class Juego {
    // Opciones posibles
    Map<String, JugadaInterface> opcionesValidasCPU = Map.of(
            "piedra", new Piedra(),
            "papel", new Papel(),
            "tijera", new Tijera()
    );
    // Crear un objeto Scanner para leer la entrada del usuario
    private Scanner scanner = new Scanner(System.in);

    public void iniciar() {
        boolean continuar = true;
        while (continuar) {
            JugadaInterface eleccionUsuario = elegirElementoUsuario(scanner);
            JugadaInterface eleccionComputadora = elegirElementoComputadora(opcionesValidasCPU);

            // Mostrar las elecciones de ambos jugadores
            System.out.println("Tu elección: " + eleccionUsuario);
            System.out.println("Elección de la computadora: " + eleccionComputadora);

            // Mostrar el resultado
            System.out.println(new Jugada().jugar(eleccionUsuario, eleccionComputadora));

            continuar = preguntarSiQueremosContinuar();
        }// end while

        System.out.println("¡Hasta pronto!");
        scanner.close();
    }

    private JugadaInterface elegirElementoUsuario(Scanner scanner) {
        // Solicitar al usuario que ingrese su elección
        Map<String, JugadaInterface> opcionesValidas = Map.of(
                "piedra", new Piedra(),
                "papel", new Papel(),
                "tijera", new Tijera()
        );
        while (true) {
            System.out.println("Elige una opción: piedra, papel o tijera");
            String eleccion = scanner.nextLine().toLowerCase().trim();

            if (opcionesValidas.containsKey(eleccion)) {
                return opcionesValidas.get(eleccion);
            }
        }
    }

    private JugadaInterface elegirElementoComputadora(Map<String, JugadaInterface> opciones) {
        // Crear un objeto Random para generar la elección de la computadora
        Random random = new Random();
        // Generar la elección de la computadora
        int indice = random.nextInt(opciones.size());
        List<JugadaInterface> claves = new ArrayList<>(opciones.values());
        return claves.get(indice);
    }

    private boolean preguntarSiQueremosContinuar() {
        System.out.println("¿Desea continuar? s/n");
        Scanner scanner = new Scanner(System.in);
        String respuesta = scanner.nextLine();
        return respuesta.toLowerCase().charAt(0) == 's';
    }
}
