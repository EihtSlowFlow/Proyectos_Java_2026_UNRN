package juego;

public class Jugada {
    public static final String PIEDRA = "piedra";
    public static final String TIJERA = "tijera";
    public static final String PAPEL = "papel";
    public static final String GANASTE = "¡Ganaste!";
    public static final String PERDISTE = "¡Perdiste!";
    public static final String EMPATE = "¡Es un empate!";

    public String jugar(JugadaInterface eleccionUsuario, JugadaInterface eleccionComputadora) {
        String resultado;
        if (eleccionUsuario.leGanaA(eleccionComputadora) == Resultado.GANO){
            resultado= GANASTE;
        }else if (eleccionUsuario.leGanaA(eleccionComputadora) == Resultado.EMPATO){
            resultado= EMPATE;
        }else{
            resultado = PERDISTE;
        }

        return resultado;
    }
}
