package juego;

public abstract class JugadaInterface {
    /*
    Lo que tengo que abstraer con DD
    if (eleccionUsuario.equals(eleccionComputadora)) {
            resultado = EMPATE;
        } else if ((eleccionUsuario.equals(PIEDRA) && eleccionComputadora.equals(TIJERA)) ||
                (eleccionUsuario.equals(PAPEL) && eleccionComputadora.equals(PIEDRA)) ||
                (eleccionUsuario.equals(TIJERA) && eleccionComputadora.equals(PAPEL))) {
            resultado = GANASTE;
        } else {
            resultado = PERDISTE;
        }
    El empate puedo resolverlo en el momento, para evitar un quinto METHOD
     */
    abstract Resultado leGanaA(JugadaInterface eleccionCPU);
    /*
    abstract boolean pierdeContraTijera();
    abstract boolean pierdeContraPiedra();
    abstract boolean pierdeContraPapel();
     */
    abstract Resultado contra(Piedra piedraCPU);
    abstract Resultado contra(Papel papelCPU);
    abstract Resultado contra(Tijera tijeraCPU);

}
