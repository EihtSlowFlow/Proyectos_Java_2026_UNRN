package juego;

public class Papel extends JugadaInterface {

    @Override
    Resultado leGanaA(JugadaInterface eleccionCPU) {
        return eleccionCPU.contra(this);
    }

    @Override
    Resultado contra(Piedra piedraCPU) {
        return Resultado.PERDIO;
    }

    @Override
    Resultado contra(Papel papelCPU) {
        return Resultado.EMPATO;
    }

    @Override
    Resultado contra(Tijera tijeraCPU) {
        return Resultado.GANO;
    }
    @Override
    public String toString() {
        return "Papel";
    }


}
