package juego;

public class Piedra extends JugadaInterface {

    @Override
    Resultado leGanaA(JugadaInterface eleccionCPU) {
        return eleccionCPU.contra(this);
    }

    @Override
    Resultado contra(Piedra piedraCPU) {
        return Resultado.EMPATO;
    }

    @Override
    Resultado contra(Papel papelCPU) {
        return Resultado.GANO;
    }

    @Override
    Resultado contra(Tijera tijeraCPU) {
        return Resultado.PERDIO;
    }
    @Override
    public String toString() {
        return "Piedra";
    }

}
