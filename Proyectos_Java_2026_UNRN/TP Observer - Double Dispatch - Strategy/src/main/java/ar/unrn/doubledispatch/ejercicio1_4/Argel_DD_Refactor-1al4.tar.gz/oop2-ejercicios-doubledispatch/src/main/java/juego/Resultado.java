package juego;

public enum Resultado {
    GANO,PERDIO,EMPATO
}
