package juego;

public class Tijera extends JugadaInterface {

    @Override
    Resultado leGanaA(JugadaInterface eleccionCPU) {
        return eleccionCPU.contra(this);
    }

    @Override
    Resultado contra(Piedra piedraCPU) {
        return Resultado.GANO;
    }

    @Override
    Resultado contra(Papel papelCPU) {
        return Resultado.PERDIO;
    }

    @Override
    Resultado contra(Tijera tijeraCPU) {
        return Resultado.EMPATO;
    }
    @Override
    public String toString() {
        return "Tijera";
    }


}
