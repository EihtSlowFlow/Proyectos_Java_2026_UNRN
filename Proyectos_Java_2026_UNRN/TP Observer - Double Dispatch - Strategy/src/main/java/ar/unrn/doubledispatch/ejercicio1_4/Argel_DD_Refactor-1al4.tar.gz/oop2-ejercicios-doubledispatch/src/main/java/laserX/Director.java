package laserX;

import java.util.ArrayList;
import java.util.List;

public class Director extends Empleado {

    public static final String VALIDA_DIRECTOR = "Como director solo mandos medios pueden estar a mi cargo";
    //public static final float SUELDO = 5000.00F;
    private String nombre;
    private float salario;
    private List<Empleado> empleados;
    public Director(String nombre, float salario) {
        this.nombre = nombre;
        this.salario = salario;
        this.empleados  = new ArrayList<>();
    }


    @Override
    public float calcularSalario() {
        float salario = this.salario;
        for(Empleado empleado : empleados){
            salario += empleado.calcularSalario();
        }
        return salario;
    }

    @Override
    public Cargo cargo() {
        return Cargo.DIRECTOR;
    }

    @Override
    public void posultarseA(Empleado emp) {
        emp.recibirSubordinado(this);
    }

    @Override
    public void recibirSubordinado(MandoMedio empleado) {
        empleados.add(empleado);
    }

    @Override
    public void recibirSubordinado(EmpleadoRegular empleado) {
        throw new RuntimeException(VALIDA_DIRECTOR);
    }

    @Override
    protected void recibirSubordinado(Director director) {
        throw new RuntimeException(VALIDA_DIRECTOR);
    }
    public boolean tieneComoSubordinado(Empleado emp) {
        // Retorna true si el objeto exacto está adentro de la lista
        return this.empleados.contains(emp);
    }
}
