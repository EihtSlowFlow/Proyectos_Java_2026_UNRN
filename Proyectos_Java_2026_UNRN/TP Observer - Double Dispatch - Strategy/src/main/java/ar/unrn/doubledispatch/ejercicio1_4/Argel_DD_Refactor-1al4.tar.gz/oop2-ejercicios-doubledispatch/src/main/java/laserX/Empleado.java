package laserX;

public abstract class Empleado {
   abstract float calcularSalario();
    abstract Cargo cargo();

    abstract void posultarseA(Empleado emp);
    abstract void recibirSubordinado(MandoMedio empleado);
    abstract void recibirSubordinado(EmpleadoRegular empleado);
    protected abstract void recibirSubordinado(Director director);
}
