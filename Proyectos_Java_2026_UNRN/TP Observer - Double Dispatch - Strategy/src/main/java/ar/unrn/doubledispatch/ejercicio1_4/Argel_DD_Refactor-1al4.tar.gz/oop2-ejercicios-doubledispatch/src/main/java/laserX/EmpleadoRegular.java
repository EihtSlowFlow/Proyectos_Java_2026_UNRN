package laserX;

public class EmpleadoRegular extends Empleado {
    private final String nombre;
    private float salario;
    private Cargo cargo;
    public static final String VALIDA_EMPLADO_JERARQUICO = "Solo directores o mandos medios son empleados jerarquicos";

    public EmpleadoRegular(String nombre, float salario) {
        this.nombre = nombre;
        this.salario = salario;
        this.cargo = Cargo.JUNIOR;
    }

    public float salario() {
        return this.salario;
    }

    @Override
    public float calcularSalario() {
        return this.salario;
    }

    @Override
    public Cargo cargo() {
        return this.cargo;
    }

    @Override
    public void posultarseA(Empleado emp) {
        emp.recibirSubordinado(this);
    }

    @Override
    void recibirSubordinado(MandoMedio empleado) {
        throw new  RuntimeException(VALIDA_EMPLADO_JERARQUICO);
    }

    @Override
    void recibirSubordinado(EmpleadoRegular empleado) {
        throw new  RuntimeException(VALIDA_EMPLADO_JERARQUICO);
    }

    @Override
    protected void recibirSubordinado(Director director) {
        throw new  RuntimeException(VALIDA_EMPLADO_JERARQUICO);
    }
}
