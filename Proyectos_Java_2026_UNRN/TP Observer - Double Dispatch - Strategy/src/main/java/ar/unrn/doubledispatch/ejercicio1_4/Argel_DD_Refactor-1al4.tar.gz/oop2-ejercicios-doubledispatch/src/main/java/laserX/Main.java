package laserX;

public class Main {
    public static void main(String[] args) {
//        var director1 = new EmpleadoJerarquico("unDirector", 100);
//        var mandoMedio = new EmpleadoJerarquico("mandoMedio", 50);
//        director1.agregarEmpleado(mandoMedio);
//        var empleadoRegular = new EmpleadoRegular("empleadoRegular", 100);
//        mandoMedio.agregarEmpleado(empleadoRegular);
//        director1.agregarEmpleado(empleadoRegular);
//        new LaserX(director1).imprimirCostoSalarial();
        var director = new Director("unDirector", 100);
        var mandoMedio = new MandoMedio("mandoMedio", 50);
        mandoMedio.posultarseA(director);
        var empleadoRegular = new EmpleadoRegular("empleadoRegular", 100);
        empleadoRegular.posultarseA(mandoMedio);
        new LaserX(director).imprimirCostoSalarial();


    }
}
