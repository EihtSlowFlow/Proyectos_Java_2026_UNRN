package laserX;

import java.util.ArrayList;
import java.util.List;

public class MandoMedio extends Empleado {
    public static final String VALIDA_MANDOMEDIO = "Como mando medio solo juniors pueden estar a mi cargo";
    private String nombre;
    private float salario;
    private List<Empleado> empleados;
    public MandoMedio(String nombre, float salario) {
        this.nombre = nombre;
        this.salario = salario;
        this.empleados  = new ArrayList<>();
    }

    @Override
    float calcularSalario() {
        float salario = this.salario;
        for(Empleado empleado : empleados){
            salario += empleado.calcularSalario();
        }
        return salario;
    }

    @Override
    Cargo cargo() {
        return Cargo.MANDOMEDIO;
    }

    @Override
    public void posultarseA(Empleado emp) {
        emp.recibirSubordinado(this);
    }

    @Override
    void recibirSubordinado(MandoMedio empleado) {
        throw new UnsupportedOperationException(VALIDA_MANDOMEDIO);
    }

    @Override
    void recibirSubordinado(EmpleadoRegular empleado) {
        this.empleados.add(empleado);
    }

    @Override
    protected void recibirSubordinado(Director director) {
        throw new UnsupportedOperationException(VALIDA_MANDOMEDIO);
    }
    public boolean tieneComoSubordinado(Empleado emp) {
        // Retorna true si el objeto exacto está adentro de la lista
        return this.empleados.contains(emp);
    }
}
