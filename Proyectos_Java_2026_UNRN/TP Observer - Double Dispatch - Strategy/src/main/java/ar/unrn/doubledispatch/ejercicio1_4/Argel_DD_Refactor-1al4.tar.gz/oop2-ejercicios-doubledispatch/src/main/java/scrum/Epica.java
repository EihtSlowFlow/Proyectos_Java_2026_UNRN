package scrum;

import java.util.ArrayList;
import java.util.List;

public class Epica extends ItemDeProyecto {
    public static final String ACCION_IMPOSIBLE_HISTORIA = "Una historia de usuario no puede ser agregada a una epica";
    public static final String ACCION_IMPOSIBLE_EPICA = "Una epica no puede ser agregada a otra epica";
    private String nombre;
    private int tiempoEstimado;
    private List<ItemDeProyecto> items;
    TipoTarea tipoTarea;

    public Epica(String nombre, int tiempoEstimado) {
        this.nombre = nombre;
        this.tiempoEstimado = tiempoEstimado;
        this.items = new ArrayList<>();
        tipoTarea =  TipoTarea.EPICA;
    }

    @Override
    int horasTotales() {
        int total = tiempoEstimado;
        for (ItemDeProyecto item : items) {
            total += item.horasTotales();
        }
        return total;
    }

    @Override
    TipoTarea tipoTarea() {
        return this.tipoTarea;
    }

    @Override
    void intentarIngresarA(ItemDeProyecto it) {
        it.agregar(this);
    }

    @Override
    void agregar(Epica epica) {
        throw new UnsupportedOperationException(ACCION_IMPOSIBLE_EPICA);
    }

    @Override
    void agregar(HistoriaUsuario historia) {
        throw new UnsupportedOperationException(ACCION_IMPOSIBLE_HISTORIA);
    }

    @Override
    void agregar(Spike spike) {
        items.add(spike);
    }

    @Override
    void agregar(TareaDesarrollo tarea) {
        throw new UnsupportedOperationException("Una tarea de desarrollo no puede ser agregada a una epica");
    }
}
