package scrum;

import java.util.ArrayList;
import java.util.List;

public class HistoriaUsuario extends ItemDeProyecto{
    public static final String VALIDA_HISTORIA = "Solo tareas de desarrollo se permiten en una historia de usuario";
    List<ItemDeProyecto> items;
    private int horasEstimadas;
    TipoTarea tipoTarea;
    public HistoriaUsuario(int horasEstimadas) {
        this.items = new ArrayList<>();
        this.horasEstimadas = horasEstimadas;
        this.tipoTarea = TipoTarea.HISTORIA_USUARIO;
    }

    @Override
    public int horasTotales() {
        int tiempoTotalEstimado = horasEstimadas;
        for (ItemDeProyecto item : items) {
            tiempoTotalEstimado += item.horasTotales();
        }
        return tiempoTotalEstimado;
    }

    @Override
    public TipoTarea tipoTarea() {
        return tipoTarea;
    }

    @Override
    public void intentarIngresarA(ItemDeProyecto it) {
        it.agregar(this);
    }

    @Override
    public void agregar(Epica epica) {
        throw new UnsupportedOperationException(VALIDA_HISTORIA);
    }

    @Override
    public void agregar(HistoriaUsuario historia) {
        throw new UnsupportedOperationException(VALIDA_HISTORIA);
    }

    @Override
    public void agregar(Spike spike) {
        throw new UnsupportedOperationException(VALIDA_HISTORIA);
    }

    @Override
    public void agregar(TareaDesarrollo tarea) {
        this.items.add(tarea);
    }
}
