package scrum;

public abstract class ItemDeProyecto {
    abstract int horasTotales();
    abstract TipoTarea tipoTarea();
    abstract void intentarIngresarA(ItemDeProyecto it);
    abstract void agregar(Epica epica);
    abstract void agregar(HistoriaUsuario historia);
    abstract void agregar(Spike spike);
    abstract void agregar(TareaDesarrollo tarea);

}
