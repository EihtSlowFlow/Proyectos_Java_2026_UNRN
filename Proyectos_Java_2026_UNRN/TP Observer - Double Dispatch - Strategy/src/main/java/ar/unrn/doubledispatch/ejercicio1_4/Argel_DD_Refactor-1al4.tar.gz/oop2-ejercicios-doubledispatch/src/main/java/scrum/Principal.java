package scrum;

public class Principal {
    public static void main(String[] args) {
        ItemDeProyecto tareaDesarrollo = new TareaDesarrollo(5);
        Spike spike = new Spike(3);
        HistoriaUsuario historiaUsuario = new HistoriaUsuario(2);
        tareaDesarrollo.intentarIngresarA(historiaUsuario);
      //  spike.intentarIngresarA(historiaUsuario);
        System.out.println("Horas totales de la historia de usuario: " + historiaUsuario.horasTotales());
        System.out.println("----------------");
        ItemDeProyecto epica = new Epica("Epica", 99);
        spike.intentarIngresarA(epica);
        System.out.println("Horas totales de la epica: " + epica.horasTotales());

    }
}
