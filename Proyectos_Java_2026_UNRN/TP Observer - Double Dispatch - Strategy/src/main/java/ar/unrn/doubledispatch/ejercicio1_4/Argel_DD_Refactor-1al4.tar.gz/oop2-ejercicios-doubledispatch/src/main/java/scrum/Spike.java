package scrum;

public class Spike extends ItemDeProyecto{

    public static final String SPIKE_ADV = "No se pueden agregar elementos a una tarea de desarrollo";
    int horasTotales = 0;
    TipoTarea tipoTarea;
    public Spike(int horasEstimadas) {
        this.horasTotales = horasEstimadas;
        tipoTarea = TipoTarea.SPIKE;
    }




    @Override
    int horasTotales() {
        return horasTotales;
    }

    @Override
    TipoTarea tipoTarea() {
        return this.tipoTarea;
    }

    @Override
    void intentarIngresarA(ItemDeProyecto it) {
        it.agregar(this);
    }

    @Override
    void agregar(Epica epica) {
        throw new UnsupportedOperationException(SPIKE_ADV);
    }

    @Override
    void agregar(HistoriaUsuario historia) {
        throw new UnsupportedOperationException(SPIKE_ADV);
    }

    @Override
    void agregar(Spike spike) {
        throw new UnsupportedOperationException(SPIKE_ADV);
    }

    @Override
    void agregar(TareaDesarrollo tarea) {
        throw new UnsupportedOperationException(SPIKE_ADV);
    }
}
