package scrum;

public class TareaDesarrollo extends ItemDeProyecto {
    private int horas;
    public final static String TAREA_HOJA_ADV = "No se pueden agregar elementos a una tarea de desarrollo";
    TipoTarea tipoTarea;
    public TareaDesarrollo(int horas) {
        this.horas = horas;
        tipoTarea = TipoTarea.TAREA_DESARROLLO;
    }

    @Override
    int horasTotales() {
        return horas;
    }

    @Override
    TipoTarea tipoTarea() {
        return tipoTarea;
    }

    @Override
    void intentarIngresarA(ItemDeProyecto it) {
        it.agregar(this);
    }

    @Override
    void agregar(Epica epica) {
        throw new UnsupportedOperationException(TAREA_HOJA_ADV);
    }

    @Override
    void agregar(HistoriaUsuario historia) {
        throw new UnsupportedOperationException(TAREA_HOJA_ADV);
    }

    @Override
    void agregar(Spike spike) {
        throw new UnsupportedOperationException(TAREA_HOJA_ADV);
    }

    @Override
    void agregar(TareaDesarrollo tarea) {
        throw new UnsupportedOperationException(TAREA_HOJA_ADV);
    }
}
