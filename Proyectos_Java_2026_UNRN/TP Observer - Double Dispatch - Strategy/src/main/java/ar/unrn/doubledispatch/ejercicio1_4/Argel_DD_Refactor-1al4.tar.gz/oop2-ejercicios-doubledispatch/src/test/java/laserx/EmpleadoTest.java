package laserx;

import laserX.*;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class EmpleadoTest {

    @Test
    public void calculoSalarial() {
        var director = new Director("unDirector", 100);
        var mandoMedio = new MandoMedio("mandoMedio", 50);
        mandoMedio.posultarseA(director);
        var empleadoRegular = new EmpleadoRegular("empleadoRegular", 100);
        empleadoRegular.posultarseA(mandoMedio);
        assertEquals(250, new LaserX(director).masaSalarial());
    }


    @Test
    public void directorNoPuedeSerJefeDeJunior() {
        var director = new Director("unDirector", 100);
        var junior = new EmpleadoRegular("unJunior", 30);

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            junior.posultarseA(director);
        });

        String mensajeEsperado = "Como director solo mandos medios pueden estar a mi cargo";
        assertEquals(mensajeEsperado, exception.getMessage());
    }

    @Test
    public void mandoMedioNoPuedeSerJefeDeDirector() {
        var director = new Director("unDirector", 100);
        var mandoMedio = new MandoMedio("mandoMedioJeje", 50);

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            director.posultarseA(mandoMedio);
        });

        String mensajeEsperado = "Como mando medio solo juniors pueden estar a mi cargo";
        assertEquals(mensajeEsperado, exception.getMessage());
    }

    @Test
    public void directorPuedeSerJefeDeMandoMedio() {
        var director = new Director("unDirector", 100);
        var mandoMedio = new MandoMedio("mandoMedio", 50);
        mandoMedio.posultarseA(director);
        assertTrue(director.tieneComoSubordinado(mandoMedio));
    }

   @Test
    public void mandoMedioPuedeSerJefeDeJunior() {
        var mandoMedio = new MandoMedio("mandoMedio", 50);
        var empleadoRegular = new EmpleadoRegular("empleadoRegular", 100);
        empleadoRegular.posultarseA(mandoMedio);
        assertTrue(mandoMedio.tieneComoSubordinado(empleadoRegular));
   }
}
