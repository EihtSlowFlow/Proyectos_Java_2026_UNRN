package scrum;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ProyectoTest {

    @Test
    public void historiaNoPuedeContenerAHistoria() {
        var historiaAnfitriona = new HistoriaUsuario(10);
        var historiaInvitada = new HistoriaUsuario(20);

        var e = assertThrows(UnsupportedOperationException.class, () -> historiaInvitada.intentarIngresarA(historiaAnfitriona));

        assertEquals(HistoriaUsuario.VALIDA_HISTORIA, e.getMessage());
    }

    @Test
    public void historiaNoPuedeContenerASpike() {
        var historia = new HistoriaUsuario(15);
        var spike = new Spike(8);

        var e = assertThrows(UnsupportedOperationException.class, () -> spike.intentarIngresarA(historia));

        assertEquals(HistoriaUsuario.VALIDA_HISTORIA, e.getMessage());
    }

    @Test
    public void epicaNoPuedeContenerOtraEpica() {
        var epicaMadre = new Epica("Épica Principal", 100);
        var epicaHija = new Epica("Sub Épica", 40);

        var e = assertThrows(UnsupportedOperationException.class, () -> epicaHija.intentarIngresarA(epicaMadre));

        assertEquals(Epica.ACCION_IMPOSIBLE_EPICA, e.getMessage());
    }

    @Test
    public void epicaNoPuedeContenerHistoriaUsuario() {
        var epica = new Epica("Módulo de Seguridad", 50);
        var historia = new HistoriaUsuario(30);

        var e = assertThrows(UnsupportedOperationException.class, () -> historia.intentarIngresarA(epica));

        assertEquals(Epica.ACCION_IMPOSIBLE_HISTORIA, e.getMessage());
    }

    @Test
    public void epicaNoPuedeContenerTareaDesarrollo() {
        var epica = new Epica("Core Engine", 80);
        var tarea = new TareaDesarrollo(12);

        var e = assertThrows(UnsupportedOperationException.class, () -> tarea.intentarIngresarA(epica));

        // Tu literal exacto en la clase Epica
        assertEquals("Una tarea de desarrollo no puede ser agregada a una epica", e.getMessage());
    }

    @Test
    public void noSePuedenAgregarElementosAUnSpike() {
        var spike = new Spike(10);
        var tarea = new TareaDesarrollo(5);

        var e = assertThrows(UnsupportedOperationException.class, () -> tarea.intentarIngresarA(spike));

        assertEquals(Spike.SPIKE_ADV, e.getMessage());
    }

    @Test
    public void noSePuedenAgregarElementosAUnaTareaDesarrollo() {
        var tareaAnfitriona = new TareaDesarrollo(8);
        var spike = new Spike(4);

        var e = assertThrows(UnsupportedOperationException.class, () -> spike.intentarIngresarA(tareaAnfitriona));
        assertEquals(TareaDesarrollo.TAREA_HOJA_ADV, e.getMessage());
    }

    @Test
    public void historiaSumaCorrectamenteSusTareasDeDesarrollo() {
        var historia = new HistoriaUsuario(30);
        var tarea1 = new TareaDesarrollo(10);
        var tarea2 = new TareaDesarrollo(5);

        tarea1.intentarIngresarA(historia);
        tarea2.intentarIngresarA(historia);

        // Cálculo: 30 (base) + 10 + 5 = 45
        assertEquals(45, historia.horasTotales());
    }

    @Test
    public void epicaSumaCorrectamenteSusSpikes() {
        var epica = new Epica("Refactor de Arquitectura", 60);
        var spike1 = new Spike(15);
        var spike2 = new Spike(10);
        spike1.intentarIngresarA(epica);
        spike2.intentarIngresarA(epica);
        assertEquals(85, epica.horasTotales());
    }
}